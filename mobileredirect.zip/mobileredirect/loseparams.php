<?php
    include_once('mobileredirect.inc');
    redirectMobileUser("http://m.netbiscuits.com", true, false);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Hello</title>
    </head>
    <body>
        <p>Hello World</p>
    </body>
</html>
